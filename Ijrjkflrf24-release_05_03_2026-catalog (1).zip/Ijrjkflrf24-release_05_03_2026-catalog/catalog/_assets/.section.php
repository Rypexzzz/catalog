<?
$sSectionName="_assets";
?>