<?
$sSectionName="catalog.components";
?>