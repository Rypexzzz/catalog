<?
$sSectionName="catalog";
?>